funcname = 'Html'
attrs = {
    'SendHtml': 'Send'
}