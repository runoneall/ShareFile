funcname = 'Html'
attrs = {
    'SendHtml': 'Send'
}
author = 'runoneall'
version = '1.0'
introduction = '''Add Html Message Support For RyhBotPythonSDK'''